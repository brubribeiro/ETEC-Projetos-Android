package br.com.etec;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText editValor1, editValor2;
    Button botaoSomar, botaoSubtrair, botaoMultiplicar, botaoDividir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editValor1 = (EditText) findViewById(R.id.edtValor1);
        editValor2 = (EditText) findViewById(R.id.edtValor2);
        botaoSomar = (Button) findViewById(R.id.btnSomar);
        botaoSubtrair = (Button) findViewById(R.id.btnSubtrair);
        botaoMultiplicar = (Button) findViewById(R.id.btnMultiplicar);
        botaoDividir = (Button) findViewById(R.id.btnDividir);

        botaoSomar.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){

                float valor1, valor2, resultado;

                valor1 = Float.parseFloat(editValor1.getText().toString());
                valor2 = Float.parseFloat(editValor2.getText().toString());

                resultado = valor1 + valor2;

                Toast.makeText(MainActivity.this, "O resultado é:" +
                        resultado, Toast.LENGTH_LONG).show();
            }
        });

        botaoSubtrair.setOnClickListener(new View.OnClickListener(){
        public void onClick(View v){

            float valor1, valor2, resultado;

            valor1 = Float.parseFloat(editValor1.getText().toString());
            valor2 = Float.parseFloat(editValor2.getText().toString());

            resultado = valor1 - valor2;

            Toast.makeText(MainActivity.this, "O resultado é:" +
                    resultado, Toast.LENGTH_LONG).show();
        }
    });

        botaoMultiplicar.setOnClickListener(new View.OnClickListener(){
        public void onClick(View v){

        float valor1, valor2, resultado;

        valor1 = Float.parseFloat(editValor1.getText().toString());
        valor2 = Float.parseFloat(editValor2.getText().toString());

        resultado = valor1 * valor2;

        Toast.makeText(MainActivity.this, "O resultado é:" +
        resultado, Toast.LENGTH_LONG).show();
        }
        });

        botaoDividir.setOnClickListener(new View.OnClickListener(){
        public void onClick(View v){

        float valor1, valor2, resultado;

        valor1 = Float.parseFloat(editValor1.getText().toString());
        valor2 = Float.parseFloat(editValor2.getText().toString());

        resultado = valor1 / valor2;

        Toast.makeText(MainActivity.this, "O resultado é:" +
        resultado, Toast.LENGTH_LONG).show();
        }
        });
    }
}
