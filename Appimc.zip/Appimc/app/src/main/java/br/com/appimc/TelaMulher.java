package br.com.appimc;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class TelaMulher extends AppCompatActivity {

    Button botaocalcM;
    EditText altura;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_mulher);

        botaocalcM = (Button)findViewById(R.id.btnCalcM);
        altura = (EditText) findViewById(R.id.edtAltura);


        botaocalcM.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){

                float altura, pesoIdeal;

                altura= Float.parseFloat(edtAltura.getText().toString());

                pesoIdeal = altura * 62.1;

                Toast.makeText(TelaMulher.this, "O resultado é:" +
                        pesoIdeal, Toast.LENGTH_LONG).show();
            }
        });
    }
}
