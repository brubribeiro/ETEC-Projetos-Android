package br.com.appimc;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class TelaHomem extends AppCompatActivity {

    Button botaocalcH;
    EditText altura;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_homem);

        botaocalcH = (Button)findViewById(R.id.btnCalcH);
        altura = (EditText) findViewById(R.id.edtAltura);


        botaocalcH.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){

             float altura, pesoIdeal;

             altura= Float.parseFloat(edtAltura.getText().toString());

             pesoIdeal = altura * 72.7;

             Toast.makeText(TelaHomem.this, "O resultado é:" +
                       pesoIdeal, Toast.LENGTH_LONG).show();
            }
        });
    }
}
