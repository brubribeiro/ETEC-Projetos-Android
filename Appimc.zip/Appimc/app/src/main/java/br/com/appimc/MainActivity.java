package br.com.appimc;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    Button menu, botao1, botao2, botaocalcM, botaocalcH;
    TextView txtMsg;
    EditText altura;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        menu = (Button)findViewById(R.id.btnMenu);
        botao1 = (Button)findViewById(R.id.btnTelaMulher);
        botao2 = (Button)findViewById(R.id.btnTelaHomem);
        botaocalcM = (Button)findViewById(R.id.btnCalcM);
        botaocalcH = (Button)findViewById(R.id.btnCalcH);
        altura = (EditText) findViewById(R.id.edtAltura);
        txtMsg = (TextView)findViewById(R.id.txtOi);

        txtMsg.setText(R.string.oi);


        menu.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if ((botao1.getVisibility() == View.VISIBLE) && (botao2.getVisibility() == View.VISIBLE));
                {
                    botao1.setVisibility(View.INVISIBLE);
                    botao2.setVisibility(View.INVISIBLE);
                }else{

                botao1.setVisibility(View.VISIBLE);
                botao2.setVisibility(View.VISIBLE);
        }}});


        botao1.setOnClickListener(new View.OnClickListener(){
        public void onClick(View v){
            Intent irTelaM = new Intent(MainActivity.this,TelaMulher.class);
            startActivity(irTelaM);
            botao1.setVisibility(View.INVISIBLE);
            botao2.setVisibility(View.INVISIBLE);
        }
    });

        botao2.setOnClickListener(new View.OnClickListener(){
        public void onClick(View v){
        Intent irTelaH = new Intent(MainActivity.this,TelaHomem.class);
        startActivity(irTelaH);
        botao1.setVisibility(View.INVISIBLE);
        botao2.setVisibility(View.INVISIBLE);
        }
        });
    }
}
