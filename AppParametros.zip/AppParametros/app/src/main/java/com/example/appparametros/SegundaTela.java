package com.example.appparametros;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SegundaTela extends AppCompatActivity {

    //Objetos das TextViews
    TextView txtnome, txtemail, txttelefone, txtendereco;

    Button btLocalizar, btEmail;
    //Vaariáveis auxiliares
    String nomeRecebido, emailRecebido, telefoneRecebido, enderecoRecebido;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda_tela);

        //Recuperação dos valores
        Intent telaAtual = getIntent();
        Bundle valores = telaAtual.getExtras();

        //Associando objetos para escrever nos TextViews
        txtnome = (TextView) findViewById(R.id.txtNome);
        txttelefone = (TextView) findViewById(R.id.txtTelefone);
        txtemail = (TextView) findViewById(R.id.txtEmail);
        txtendereco = (TextView) findViewById(R.id.txtEndereco);

        //Pegando os valores passados
        nomeRecebido = valores.getString("nome");
        telefoneRecebido = valores.getString("telefone");
        emailRecebido = valores.getString("email");
        enderecoRecebido = valores.getString("endereco");

        //Mostrando os valores nos TextViews
        txtnome.setText(nomeRecebido);
        txttelefone.setText(telefoneRecebido);
        txtemail.setText(emailRecebido);
        txtendereco.setText(enderecoRecebido);



        btLocalizar = (Button) findViewById(R.id.btnLocal);
                btLocalizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri gmmIntentUri = Uri.parse("geo:0,0?q=" + txtendereco.getText().toString());
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                startActivity(mapIntent);
            }
        });
    }
}
