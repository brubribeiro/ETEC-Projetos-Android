package com.example.appparametros;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //OBJETOS EDITEXTS
    EditText edNome, edTelefone, edEmail, edEndereco;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //ASSOCIANDO OS OBJETOS
        edNome = (EditText) findViewById(R.id.edtNome);
        edTelefone = (EditText) findViewById(R.id.edtTelefone);
        edEmail = (EditText) findViewById(R.id.edtEmail);
        edEndereco = (EditText) findViewById(R.id.edtEndereco);
    }

    //Método que envia dados
    public void enviar(View v){
        Intent tela2 = new Intent(MainActivity.this, SegundaTela.class);
        tela2.putExtra("nome",edNome.getText().toString());
        tela2.putExtra("nome",edTelefone.getText().toString());
        tela2.putExtra("email",edEmail.getText().toString());
        tela2.putExtra("nome",edEndereco.getText().toString());
        Toast.makeText(this, "Dados enviados com sucesso!", Toast.LENGTH_LONG).show();
        startActivity(tela2);
    }

}
